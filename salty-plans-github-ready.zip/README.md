# Salty Plans 🌊

A standalone coastal college planner inspired by the Salty Plans B12 design.

## Run it
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository named `salty-plans`.
2. Upload `index.html` and `README.md`.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will give you a public `github.io` address.

## Current features
- Coastal responsive UI
- Today dashboard
- Monthly calendar
- Add/remove plans
- To-do list with saved completion state
- XP and level system
- Streak display
- Gentle goals with progress
- Brain dump with autosave
- Music-player-style controls
- Weekly reset
- Local browser saving
- Mobile navigation
- Dark-mode toggle

## Notes
This version stores data in the browser with localStorage. It does not yet have accounts or cloud sync. Those can be added later with a backend such as Supabase.
